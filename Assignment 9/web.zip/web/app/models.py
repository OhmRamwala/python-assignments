from django.db import models as model

# Create your models here.
class contact(model.Model):
    first_name = model.CharField(max_length=30)
    last_name = model.CharField(max_length=30)
    email = model.EmailField()
    content = model.TextField(max_length=500)
