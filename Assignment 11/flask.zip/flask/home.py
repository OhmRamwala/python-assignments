#Importing flask main
from flask import Flask, render_template, request, url_for
import os

#interaction
web = Flask(__name__)


#mapping of pages
@web.route('/')
@web.route('/register')

#inputs
def home():
    pic = url_for('static', filename='image.png')
    return render_template('register.html',user_image=pic) # This will show up in the browser

@web.route('/confirmation',methods=['POST','GET'])

def confirmation():
    if request.method == 'POST':
        fn = request.form.get('fname')
        ln = request.form.get('lname')
        email = request.form.get('email')
        usr = request.form.get('username')
        pssw = request.form.get('password')
    return render_template('confirm.html',fname=fn,lname=ln,email=email,usr=usr,pssw=pssw)

#main
if __name__ == "__main__":
    web.run(debug=True)
