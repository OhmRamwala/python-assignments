from django.urls import path
from blog import views

urlpatterns = [
    path('', views.allpost, name='allpost'),
    path('post/<int:blog_id>/', views.details, name='details'),
]
