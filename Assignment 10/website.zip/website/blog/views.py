from django.shortcuts import render, get_object_or_404
from blog.models import Post

def allpost(request):
    posts = Post.objects.all()
    return render(request, 'blog/posts.html', {'posts': posts})

def details(request, blog_id):
    post = get_object_or_404(Post, pk=blog_id)
    return render(request, 'blog/details.html', {'post': post})
